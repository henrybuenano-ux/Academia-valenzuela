<?php
/**
 * Plugin Name: 00 — Omnia EvoCampus Config (PRODUCCIÓN)
 * Description: Constantes de configuración del plugin "EvoCampus ↔ WooCommerce Subscriptions Sync". El prefijo "00" hace que cargue ANTES que el plugin principal.
 * Version:     1.0.0
 * Author:      Omnia
 *
 * ⚠️ FALTAN DOS SECRETOS — buscarlos en el config del STAGING y pegarlos abajo:
 *      1) OMNIA_EVO_KEY  → key de la API de EvoCampus
 *      2) OMNIA_GHL_PIT  → Private Integration Token de GoHighLevel
 *    Mientras tengan el texto PEGAR-AQUI, el plugin avisará y no hará nada.
 */

defined( 'ABSPATH' ) || exit;

/* ── EvoCampus ─────────────────────────────────────────────── */
if ( ! defined( 'OMNIA_EVO_CLIENTID' ) ) {
	define( 'OMNIA_EVO_CLIENTID', '83208' );
}
if ( ! defined( 'OMNIA_EVO_KEY' ) ) {
	define( 'OMNIA_EVO_KEY', 'PEGAR-AQUI-LA-KEY-DE-EVOCAMPUS' );   // ← SECRETO 1
}

/* ── Modo de funcionamiento ────────────────────────────────── */
if ( ! defined( 'OMNIA_EVO_DRYRUN' ) ) {
	// true = solo observa y registra. NO cambiar a false hasta el 1-sep.
	define( 'OMNIA_EVO_DRYRUN', true );
}
if ( ! defined( 'OMNIA_GHL_DRYRUN' ) ) {
	// true las primeras 24 h para simular también el espejo del CRM.
	define( 'OMNIA_GHL_DRYRUN', true );
}
if ( ! defined( 'OMNIA_EVO_GRACE_DAYS' ) ) {
	// Ciclo mensual (31) + 7 días de cortesía (política A6, Paco 14-jul-2026).
	define( 'OMNIA_EVO_GRACE_DAYS', 38 );
}

/* ── Becados autorizados (Paco, 14-jul-2026) ───────────────── */
if ( ! defined( 'OMNIA_EVO_BECADOS_EMAILS' ) ) {
	define( 'OMNIA_EVO_BECADOS_EMAILS', 'danielsanchezluc55@gmail.com,mirellacrespo29@gmail.com,juanjolirio2003@gmail.com,juncaluam@gmail.com,marioventapuer@hotmail.com,santiml.89@hotmail.com,sergiohuelma_123@hotmail.com' );
}

/* ── GoHighLevel ───────────────────────────────────────────── */
if ( ! defined( 'OMNIA_GHL_PIT' ) ) {
	define( 'OMNIA_GHL_PIT', 'PEGAR-AQUI-EL-PIT-DE-GHL' );          // ← SECRETO 2
}
if ( ! defined( 'OMNIA_GHL_LOCATION_ID' ) ) {
	define( 'OMNIA_GHL_LOCATION_ID', 'hBvP7lemQSMibPYcJPEP' );
}
if ( ! defined( 'OMNIA_GHL_WEBHOOK_URL_BAJA' ) ) {
	define( 'OMNIA_GHL_WEBHOOK_URL_BAJA', 'https://services.leadconnectorhq.com/hooks/hBvP7lemQSMibPYcJPEP/webhook-trigger/vJkOtiVDBtx0TChtWl9U' );
}
if ( ! defined( 'OMNIA_GHL_WEBHOOK_URL_REACTIVACION' ) ) {
	define( 'OMNIA_GHL_WEBHOOK_URL_REACTIVACION', 'https://services.leadconnectorhq.com/hooks/hBvP7lemQSMibPYcJPEP/webhook-trigger/DHGCTUxHMdwjVIMKbSOt' );
}
